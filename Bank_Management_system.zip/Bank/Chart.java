package com.company;

import java.sql.*;
import java.io.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartUtils;
 public class Chart {
         public Chart() {
             try {
             Class.forName ("oracle.jdbc.OracleDriver");
             Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe", "ABC", "2482002");
             DefaultCategoryDataset my_bar_chart_dataset = new DefaultCategoryDataset();
             Statement stmt = conn.createStatement();

                 ResultSet query_set = stmt.executeQuery("select ACCOUNT_NUMBER,WITHDRAW from Account_data");
                 while (query_set.next()) {
                     String category = query_set.getString("ACCOUNT_NUMBER");
                     int withdraw = query_set.getInt("WITHDRAW");
                     my_bar_chart_dataset.addValue(withdraw,"WITHDRAW",category);
                 }
                 JFreeChart BarChartObject=ChartFactory.createBarChart("Withdraw stats - Bar Chart","ACCOUNT_NUMBER","WITHDRAW",my_bar_chart_dataset,PlotOrientation.VERTICAL,true,true,false);
                 query_set.close();
                 stmt.close();
                 conn.close();
                 int width=640; /* Width of the image */
                 int height=480; /* Height of the image */
                 File BarChart=new File("output_chart.png");
                 ChartUtils.saveChartAsPNG(BarChart,BarChartObject,width,height);
             }
             catch (Exception i)
             {
                 System.out.println(i);
             }

         }

    public static void main(String[] args) {
             Chart c=new Chart();

} }